﻿// (C) Copyright 2002-2013 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices.Filters;
using Autodesk.AutoCAD.Windows.ToolPalette;
using System.Windows.Forms;
using Autodesk.AutoCAD.Windows;
 
namespace AcHTML
{
    public class AcHTMLCmd 
    {     
        private string SelectFile(string title, string filter, string dir)
        {
            System.Windows.Forms.OpenFileDialog ofd =
                new System.Windows.Forms.OpenFileDialog();

            ofd.Filter = filter;
            ofd.Title = title;
            ofd.InitialDirectory = dir;
            
            if (ofd.ShowDialog() != DialogResult.OK)
                return string.Empty;

            return ofd.FileName;
        }

        static Autodesk.AutoCAD.Windows.PaletteSet _ps = null;
        static string demo_site_url = "https://www.baidu.com/index.html";
        //static string demo_site_url = "http://devtechchina.github.io/AutoCAD_JS_API_TestPage";

        [CommandMethod("AdnJsDlg")]
        public void AdnJsDlg()
        {            
             Uri uri = new Uri(demo_site_url);
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalWindow(uri);
        }

        [CommandMethod("AdnJsDlgless")]
        public void AdnJsDlgless()
        {

            Uri uri = new Uri(demo_site_url);
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModelessWindow(uri);
        }

         [CommandMethod("AdnJsWin")]
        public void AdnJsWin()
        { 
            Uri uri = new Uri(demo_site_url);
            Autodesk.AutoCAD.ApplicationServices.Application.DocumentWindowCollection.AddDocumentWindow("myWindow",uri);
        }

         [CommandMethod("AdnJsDemo")]
         public void AdnJsDemo()
         {
             //获取桌面路径
             string dir = System.Environment.GetFolderPath(
                 System.Environment.SpecialFolder.Desktop);

             //选择HTML文件
             System.Windows.Forms.OpenFileDialog oFlg = new System.Windows.Forms.OpenFileDialog();
             oFlg.Title = "Select Html File to load...";
             oFlg.Filter = "Html Files (*.html)|*.html";
             if (oFlg.ShowDialog() != DialogResult.OK)
             {
                 return;
             }
             string filename = oFlg.FileName;
             if (filename == string.Empty)
                 return;

             //创建停靠窗口	
             if (_ps == null)
             {
                 _ps = new Autodesk.AutoCAD.Windows.PaletteSet(
                     "JavaScript Demo",
                     new Guid("730CF323-7D71-40A1-990E-F7CF81A84340"));
             }

             String url = "file:///" + filename;
             try
             {
                 //停靠窗口显示名
                 String tabName = "我的JS停靠窗口";
                 Uri uri = new Uri(url); 

                 if (_ps.Count != 0)
                 {
                     _ps[0].PaletteSet.Remove(0);
                 }

                 // 使用HTML文件或URL作为停靠窗口的参数  
                 Palette p = _ps.Add(tabName, uri);

                 _ps.Visible = true;
             }
             catch (UriFormatException ex)
             {
                 // 抛出可能异常 
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
         }
    }
}
